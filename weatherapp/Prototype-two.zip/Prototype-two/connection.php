<?php

$hostname ="localhost";
$username = "root";
$password = "";
$databaseName = "Prototype_Two";

$con = mysqli_connect($hostname, $username, $password, $databaseName); //connecting php and database in localhost



?>